ColorCs-Safety All Versions i Deleted trea.exe, ColorCs.exe All Versions i added trea.exe.

Made by kapi2.0peys
Requieres NET 3.5 Framework